setwd("C:\\Users\\it24100860\\Desktop\\IT24100860")
data<-read.table("Exercise - LaptopsWeights.txt",header=TRUE)

#Q1
popmn<-mean(Weight.kg.)
popmn
pop_sd<-sd(Weight.kg.)
pop_sd

# Q2
sample<-c()
n<-c()
for(i in 1:25){
  s<-sample(Weight.kg.,6,replace = TRUE)
  sample<-cbind(sample,s)
  n<-c(n,paste('S',i))
}
colnames(sample)=n
s.means<-apply(sample,2,mean)
s.means
s.sd<-apply(sample,2,sd)
s.sd

#Q3
#calculate the mean and standard deviation of the 25 sample means 
samplemean<-mean(s.means)
samplemean
samplesd<-sd(s.sd)
samplesd

#state therelationship of them with true mean and true standard deviation
popmn
samplemean

truesd=pop_sd/5
samplesd
